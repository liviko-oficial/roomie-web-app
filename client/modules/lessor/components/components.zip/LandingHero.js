import React from 'react';

const LandingHero = () => {
  return (
    <section className="relative w-full min-h-screen flex items-center justify-center bg-white text-black overflow-hidden"> {/* Añadido pt-20 para móviles */}
      <div className="container mx-auto px-6 py-12 flex flex-col md:flex-row items-center justify-between z-10">
        <div className="md:w-1/2 text-center md:text-left mb-12 md:mb-0">
          <h1 className="text-4xl md:text-6xl font-extrabold mb-4 md:mb-6 leading-tight">
            ¡RENTA TU PROPIEDAD DE MANERA <span className="text-yellow-400">FÁCIL Y SEGURA!</span>
          </h1>
          <p className="text-lg md:text-2xl font-medium mb-6 md:mb-8">
            Conecta con estudiantes del Tec de Monterrey y <span className="font-bold">maximiza tus ingresos</span>
          </p>
          <a href="#registro" className="inline-block bg-yellow-400 text-black py-3 px-8 rounded-lg text-lg md:text-xl font-medium hover:bg-yellow-500 transition-colors shadow-md">
            Publica tu propiedad
          </a>
        </div>
        
        <div className="md:w-1/2 flex justify-center md:justify-end mt-8 md:mt-0">
          <div className="relative w-full max-w-md md:max-w-lg">
            <div className="absolute -top-4 -left-4 w-full h-full bg-yellow-400 rounded-xl"></div>
            <div className="relative z-10 w-full rounded-xl shadow-2xl overflow-hidden transform transition-transform hover:scale-105 duration-300">
              {/* Imagen con overlay amarillo */}
              <div className="relative">
                <img 
                  src="https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80" 
                  alt="Apartamento moderno" 
                  className="w-full h-auto object-cover"
                  style={{minHeight: "300px", maxHeight: "450px"}} // Ajuste de altura para móviles
                />
                {/* Overlay amarillo sutil */}
                <div className="absolute inset-0 bg-yellow-400 opacity-10"></div>
              </div>
            </div>
            <div className="absolute -bottom-4 -right-4 bg-black text-white px-4 py-2 md:px-6 md:py-3 rounded-lg shadow-lg z-20 font-bold text-sm md:text-base">
              ¡Alta demanda!
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default LandingHero;
